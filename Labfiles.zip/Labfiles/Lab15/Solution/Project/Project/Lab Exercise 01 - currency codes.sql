-- Module 15 Exercise 1

-- Task 1 -review imported data
USE AdventureWorks;
GO
SELECT * FROM Accounts.CurrencyCode;
GO
